apicall <- function(path) {
    apiBase <- dcOpts('apiBase', 'https://dcs-api.dev.nibr.novartis.net')
    authentication <- dcOpts('auth')
    resp <- httr::GET(httr::modify_url(apiBase, path = path), authentication)
    jsonlite::fromJSON(httr::content(resp, 'text'))
}

#' @export
domains <- function() {
    resp <- apicall('domains')
    resp$members
}

dcOpts <- function(name, default = NULL) {
    opts <- getOption('dcOpts', default = list())
    opt <- opts[[name]]
    if (is.null(opt)) default
    else opt
}
